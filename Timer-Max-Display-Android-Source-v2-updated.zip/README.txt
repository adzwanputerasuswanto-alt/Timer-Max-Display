TIMER MAX DISPLAY V2 — UPDATED SOURCE

Pembaruan:
- Tampilan merah glossy, putih, hitam, dan aksen kuning.
- Enam kartu timer dalam susunan dua kolom pada layar HP.
- Kalkulator proporsional: 10 PLU = 60 detik; 1 PLU = 6 detik.
- Contoh: 13 PLU = 78 detik = 01:18.
- Tidak menggunakan pembulatan per kelompok PLU.
- Timer independen dengan tombol Mulai, Jeda, Reset.
- Nama timer, jumlah PLU, status, dan waktu akhir disimpan lokal.
- Tambah baris timer hingga 30 baris.
- Riwayat aktivitas timer, halaman Tentang, dan navigasi bawah.
- Logo Alfamart dan sirine MP3 asli dipertahankan.

BUILD APK:
1. Upload isi folder project ini ke repository GitHub (jangan upload ZIP sebagai isi project).
2. Pastikan folder .github/workflows ikut diunggah.
3. Buka tab Actions.
4. Jalankan workflow Build Timer Max Display APK.
5. Setelah hijau, unduh Artifact Timer-Max-Display-APK.
6. Ekstrak artifact dan pasang app-debug.apk.

Catatan:
- Build memakai Java 17 dan Gradle 8.9.
- Timer WebView diperbarui berdasarkan timestamp saat aplikasi kembali aktif. Android dapat membatasi audio/proses ketika aplikasi benar-benar ditutup atau dibatasi baterai; layanan foreground native diperlukan untuk jaminan alarm latar belakang.
- Volume audio aplikasi disetel 100%, tetapi volume media fisik tetap mengikuti pengaturan perangkat.
