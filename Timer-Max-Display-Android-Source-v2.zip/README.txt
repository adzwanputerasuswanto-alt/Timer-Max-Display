TIMER MAX DISPLAY — SOURCE PROJECT

Fitur versi 1:
- 6 timer independen: Mulai, Jeda, Reset
- Nama setiap baris dapat diedit
- Rumus awal: 10 PLU = 1 menit
- Metode fixed per kelompok: waktu = ceil(jumlah PLU / PLU_per_menit) x 60 detik
- Pengaturan jumlah PLU per menit dapat diubah
- Kalkulator estimasi
- Penyimpanan nama, jumlah PLU, rumus, dan status timer di perangkat
- Sirine MP3 yang disediakan pengguna, diputar berulang dengan volume aplikasi 100%, plus getaran
- Logo Alfamart menggunakan file gambar persis seperti yang diunggah pengguna
- Nama baris dan jumlah PLU disimpan lokal agar tetap ada setelah aplikasi ditutup/dibuka ulang

MEMBANGUN APK DENGAN HP ANDROID MELALUI GITHUB:
1. Ekstrak ZIP ini.
2. Buat repository baru di GitHub, misalnya timer-max-display.
3. Upload seluruh isi folder proyek (bukan folder luarnya) ke repository, pastikan folder .github ikut ter-upload.
4. Buka tab Actions, pilih workflow "Build Timer Max Display APK".
5. Tekan Run workflow dan tunggu sampai selesai.
6. Buka hasil workflow yang hijau, cari Artifacts, unduh Timer-Max-Display-APK.
7. Ekstrak ZIP artifact dan pasang app-debug.apk.

CATATAN:
Ini paket source awal untuk membangun APK. Timer dan sirine berbasis WebView; Android dapat membatasi proses dan audio ketika aplikasi benar-benar berada di latar belakang atau perangkat menghemat baterai. Versi berikutnya perlu menambahkan Android foreground service dan alarm sistem agar bunyi latar belakang lebih andal.

CATATAN AUDIO:
Volume pemutaran di aplikasi disetel 100%. Tingkat suara fisik tetap mengikuti volume media perangkat Android; aplikasi tidak memaksa volume sistem ke maksimum. Audio latar belakang dan timer saat aplikasi ditutup masih memerlukan implementasi Android foreground service pada versi lanjutan.
